"""test empty docstrings
"""

__revision__ = ''

def function():
    """"""
