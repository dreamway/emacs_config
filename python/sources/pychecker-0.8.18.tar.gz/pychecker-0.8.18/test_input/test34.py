'd'

from string import whitespace
from string import digits
from string import lowercase
from string import *

import locale
from locale import LC_ALL
from locale import *

import getopt
from getopt import *

from copy import *
import copy

from re import sub
from re import sub

import ihooks
import ihooks

def x(a):
    "just use the imported modules so we don't get an unused warning"
    print ihooks, getopt, copy, locale

