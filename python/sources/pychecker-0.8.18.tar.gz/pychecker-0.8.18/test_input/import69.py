'd'

class Test:
    'd'
    def __init__(self): pass

class Alias(Test):
    'd'
