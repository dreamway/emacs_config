'doc'

from import24 import *

b = Bbb()

def xxx():
    print func24(1)

def func(shadow):
    print shadow

