'd'

import UserDict

def y():
  UserDict.UserDict()
  UserDict.UserDict({})
  UserDict.UserDict({}, 0)
  UserDict.UserDict({}, 0, 1)

