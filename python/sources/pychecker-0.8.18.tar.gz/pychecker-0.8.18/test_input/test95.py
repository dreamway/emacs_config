'docstring'

def try_uni():
    word = "a"
    return u"%s \N{RIGHTWARDS ARROW}" % word
