"shouldn't produce any warnings"

from xml.sax import handler

class GetGUI(handler.DTDHandler):
  "shouldn't produce any warnings"
  pass

