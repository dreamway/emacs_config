'd'

class import47:
  'this class must be named the same as the file to create a spurious warning'
  v = 'n'
  def print_version(self):
    print import47.v
