'doc'

class Aaa:
    def __init__(self):
        self.a = 1

class Bbb(Aaa):
    def __init__(self):
        self.b = 1

def func24():
    return 53

shadow = 5
